from google.cloud import bigquery, pubsub_v1
import json

def monitor_stock(request):
    """Monitor stock levels and send alerts for critical products."""
    client = bigquery.Client()

    # Requête pour détecter les produits critiques
    query = """
    SELECT
      product_id,
      product_name,
      stock_quantity,
      CASE
        WHEN stock_quantity = 0 THEN "Rupture de stock"
        WHEN stock_quantity <= 10 THEN "Proche de la rupture"
        ELSE "Stock suffisant"
      END AS stock_status
    FROM `gestion-stock-analysis.private_stock_management.products`
    WHERE stock_quantity <= 10
    ORDER BY stock_quantity ASC;
    """

    try:
        # Exécuter la requête BigQuery
        query_job = client.query(query)
        results = query_job.result()  # Attendre la fin de la requête

        # Construire la liste des produits critiques
        critical_products = []
        for row in results:
            critical_products.append({
                "product_id": row.product_id,
                "product_name": row.product_name,
                "stock_quantity": row.stock_quantity,
                "status": row.stock_status
            })

        # Vérifier les produits critiques et publier l'alerte
        if critical_products:
            # Publier une alerte sur Pub/Sub
            publish_alert(critical_products)
            response = {
                "message": "Alerte publiée avec succès",
                "products": critical_products
            }
        else:
            response = {"message": "Aucun produit critique détecté."}

        return json.dumps(response), 200  # Retourner une réponse JSON

    except Exception as e:
        error_message = f"Erreur lors de la surveillance du stock : {e}"
        print(error_message)
        return json.dumps({"error": error_message}), 500


def publish_alert(critical_products):
    """Publier une alerte avec les produits critiques sur Pub/Sub."""
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path("gestion-stock-analysis", "stock-alerts")

    # Convertir les produits en JSON
    message = json.dumps(critical_products).encode("utf-8")
    future = publisher.publish(topic_path, message)
    print(f"Alerte publiée sur Pub/Sub : {future.result()}")