import os
import json
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
import base64

def send_email_alert(event, context):
    """
    Cloud Function to send email alerts for stock issues using SendGrid.
    Triggered by a Pub/Sub message.
    """
    # Charger la clé API SendGrid depuis les variables d'environnement
    sendgrid_api_key = os.environ.get("SENDGRID_API_KEY")
    if not sendgrid_api_key:
        raise ValueError("La clé API SendGrid est manquante. Configurez-la comme variable d'environnement.")

    # Charger et décoder le message de l'événement Pub/Sub
    try:
        pubsub_message = base64.b64decode(event['data']).decode('utf-8')
        critical_products = json.loads(pubsub_message)

        if not isinstance(critical_products, list):
            raise ValueError("Le message décodé n'est pas une liste valide.")
    except Exception as e:
        critical_products = [{"message": f"Erreur de décodage du message Pub/Sub : {e}"}]

    # Construire le corps de l'email
    subject = "Alerte : Statut des stocks"
    body = "Bonjour,\n\nVoici les informations concernant les produits en stock critique :\n\n"

    if isinstance(critical_products, list):
        for product in critical_products:
            body += f"- {product['product_name']} (ID: {product['product_id']}) - Stock: {product['stock_quantity']} - Statut: {product['status']}\n"
    else:
        body += f"{critical_products}\n"

    body += "\nMerci,\nGestion Stock Analysis"

    # Configurer et envoyer l'email avec SendGrid
    message = Mail(
        from_email="sohaybelbeki@gmail.com",  # Adresse expéditrice
        to_emails="sohaybelbeki@gmail.com",  # Adresse destinataire
        subject=subject,
        plain_text_content=body
    )

    try:
        sg = SendGridAPIClient(sendgrid_api_key)
        response = sg.send(message)
        print(f"Email envoyé avec succès. Status Code: {response.status_code}")
    except Exception as e:
        print(f"Erreur lors de l'envoi de l'email : {e}")