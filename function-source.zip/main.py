from google.cloud import bigquery

def handle_csv_update(event, context):
    """Triggered by Cloud Storage. Loads specific files into BigQuery."""
    # Extraire le bucket et le fichier depuis l'événement
    bucket_name = event.get('bucket')
    file_name = event.get('name')

    if not bucket_name or not file_name:
        print("Erreur : Bucket ou nom de fichier manquant dans l'événement.")
        return

    print(f"Fichier détecté : {file_name} dans le bucket {bucket_name}")

    # Initialiser le client BigQuery
    client = bigquery.Client()

    if file_name == "products.csv":
        print("Le fichier détecté est products.csv. Chargement dans BigQuery...")
        table_id = "gestion-stock-analysis.private_stock_management.products"
        write_disposition = bigquery.WriteDisposition.WRITE_TRUNCATE  # Écrase les données existantes
        schema = None  # Pas besoin de schéma explicite pour products.csv
    elif file_name == "sales.csv":
        print("Le fichier détecté est sales.csv. Chargement dans BigQuery...")
        table_id = "gestion-stock-analysis.private_stock_management.sales"
        write_disposition = bigquery.WriteDisposition.WRITE_APPEND  # Ajoute les nouvelles lignes

        # Schéma explicite pour éviter les erreurs de type
        schema = [
            bigquery.SchemaField("sale_id", "STRING"),
            bigquery.SchemaField("product_id", "STRING"),
            bigquery.SchemaField("quantity_sold", "INTEGER"),
            bigquery.SchemaField("sale_date", "TIMESTAMP"),
        ]
    else:
        print(f"Fichier {file_name} ignoré.")
        return

    # URI du fichier dans Cloud Storage
    uri = f"gs://{bucket_name}/{file_name}"

    # Configurer le job de chargement avec un schéma strict
    job_config = bigquery.LoadJobConfig(
        source_format=bigquery.SourceFormat.CSV,
        skip_leading_rows=1,
        schema=schema,  # Schéma explicite
        write_disposition=write_disposition
    )

    try:
        # Charger les données dans BigQuery
        load_job = client.load_table_from_uri(uri, table_id, job_config=job_config)
        load_job.result()  # Attendre la fin du chargement
        print(f"Table {table_id} mise à jour avec succès.")
    except Exception as e:
        print(f"Erreur lors du chargement dans BigQuery : {e}")